# james jack
# rock paper scissors game with user input

# rules:
# Rock smashes Scissors, so Rock wins
# Scissors cut Paper, so Scissors win
# Paper covers Rock, so Paper wins
# If players choose the same weapon, neither win and the game is played again

from gameData import gamedata


def game():
    gamedata()
